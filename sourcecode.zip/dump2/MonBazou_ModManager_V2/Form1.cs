using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Media;
using System.Net;
using System.Text;
using System.Windows.Forms;
using AutoUpdaterDotNET;
using Microsoft.Win32;
using MonBazou_ModManager_V2.Properties;
using Newtonsoft.Json;

namespace MonBazou_ModManager_V2
{
	public class Form1 : Form
	{

		private const string changelogUrl = "https://pastebin.com/raw/ymvU4Qzs";

		private const string modsUrl = "https://raw.githubusercontent.com/BeterSussin/modloader/main/modurl";

		private const string bepinexUrl = "https://github.com/BepInEx/BepInEx/releases/download/v5.4.19/BepInEx_x64_5.4.19.0.zip";

		private const string autoUpdate = "https://raw.githubusercontent.com/BeterSussin/modloader/main/autoupdate.txt";

		private const string version = "1.2.3";

		private string InstallLoc = "";

		private dynamic mod;

		private IContainer components = null;

		private TabControl tabControl1;

		private TabPage mainMenu;

		private TextBox textBox1;

		private Label changelogLabel;

		private TabPage modsMenu;

		private ListView listView1;

		private GroupBox groupBox1;

		private Label steamLabel;

		private Label bepinexLabel;

		private Label installLocLabel;

		private Label label1;

		private Button bepinexConfigButton;

		private Button bepinexButton;

		private TextBox nameTextBox;

		private Label label3;

		private TextBox versionTextBox;

		private Label label2;

		private TextBox descTextBox;

		private Label label6;

		private TextBox authorTextBox;

		private Label label5;

		private TextBox releaseDateTextBox;

		private Label label4;

		private TextBox gameVersionTextBox;

		private Label reasonLabel;

		private Label disabledLabel;

		private Button deinstallButton;

		private Button installButton;

		private Button button1;

		private Label label7;

		private Button button2;

		private Label label10;

		private Label label9;

		private Label label8;

		private Button refreshButton;

		private Button forceUpdateButton;

		private Label versionlabel;

		private bool steamVersion;


		public static string Base64Decode(string base64EncodedData)
		{
			byte[] bytes = Convert.FromBase64String(base64EncodedData);
			return Encoding.UTF8.GetString(bytes);
		}

		public static string Base64Encode(string plainText)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(plainText);
			return Convert.ToBase64String(bytes);
		}

		public static bool DownloadFile(string url, string path, string agent)
		{
			try
			{
				using WebClient webClient = new WebClient();
				ServicePointManager.Expect100Continue = true;
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
				webClient.Headers.Add("user-agent", agent);
				webClient.DownloadFile(new Uri(url), path);
				return true;
			}
			catch (Exception)
			{
				return false;
			}
		}

		public Form1()
		{
			InitializeComponent();
		}

		private void Error(Exception ex, string errorCode, bool important, bool needsAttention)
		{
			if (important)
			{
				MessageBox.Show("Major error occured (ERRCODE: " + errorCode + ")\n\n" + ex.ToString(), "Mod Manager Crack - Mon Bazou", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Application.Exit();
				Application.ExitThread();
			}
			else if (needsAttention)
			{
				MessageBox.Show("Minor error occured (ERRCODE: " + errorCode + ")\n\n" + ex.ToString(), "Mod Manager Crack - Mon Bazou", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				MessageBox.Show("Minor error occured (ERRCODE: " + errorCode + ")\n\n" + ex.ToString(), "Mod Manager Crack - Mon Bazou", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		private string GetInstallLoc()
		{
			try
			{
				using RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
				RegistryKey registryKey2;
				try
				{
					registryKey2 = registryKey.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Steam App 1520370");
				}
				catch (Exception ex)
				{
					Error(ex, "INSTALLOCFAIL-SUBKEY/POSSPIR", important: true, needsAttention: false);
					return "";
				}
				object value = registryKey2.GetValue("InstallLocation");
				if (!string.IsNullOrWhiteSpace(value.ToString()))
				{
					InstallLoc = value.ToString() + "\\";
					steamVersion = true;
					return value.ToString();
				}
				Error(new Exception("InstallLocation was Empty. Please make sure to select the right folder!"), "INSTALLOCFAIL", important: true, needsAttention: false);
				return "";
			}
			catch (Exception ex)
			{
				if (File.Exists("dir.txt"))
                {
					string temp_path = File.ReadAllText("dir.txt");
					if (File.Exists(temp_path + "\\Mon Bazou.exe"))
					{
						InstallLoc = temp_path.ToString();
						steamVersion = false;
						return temp_path.ToString();
					}
				}
				using (var fbd = new FolderBrowserDialog())
				{
					fbd.Description = "Select Mon Bazou Folder!";

					DialogResult result = fbd.ShowDialog();

					if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
					{
						string[] files = Directory.GetFiles(fbd.SelectedPath);

						if (File.Exists(fbd.SelectedPath + "\\Mon Bazou.exe"))
						{
							InstallLoc = fbd.SelectedPath.ToString();
							steamVersion = false;
							string createText = fbd.SelectedPath.ToString();
							File.WriteAllText("dir.txt", createText);
							return fbd.SelectedPath.ToString();
						}
						else
						{
							return "";
						}
					}
				}
				return "";
			}
		}

		private void SetupChangelog()
		{
			textBox1.ScrollBars = ScrollBars.Both;
			try
			{
				using WebClient webClient = new WebClient();
				ServicePointManager.Expect100Continue = true;
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
				listView1.Items.Clear();

				string text = webClient.DownloadString(changelogUrl);
				textBox1.Text = text;
				
			}
			catch (Exception ex)
			{
				textBox1.Text = "Error downloading Changelog";
				Error(ex, "CHANGELOG-FULL/FAIL", important: false, needsAttention: true);
			}
		}

		private void LocSetup()
		{
			try
			{
				string installLoc = GetInstallLoc();
				if (!string.IsNullOrEmpty(installLoc))
				{
					installLocLabel.BackColor = Color.GreenYellow;
					installLocLabel.Text = "Mon Bazou Install Location: \n" + installLoc;
					if (Directory.Exists(InstallLoc + "\\BepInEx\\"))
					{
						bepinexLabel.Text = "BepInEx Installed? YES";
						bepinexLabel.BackColor = Color.GreenYellow;
						bepinexButton.Visible = true;
						bepinexButton.Visible = true;
						bepinexConfigButton.Visible = true;
					}
					else
					{
						bepinexLabel.Text = "BepInEx Installed? NO \nWill be installed when installing a mod";
						bepinexLabel.BackColor = Color.Red;
						bepinexButton.Visible = true;
						bepinexButton.Visible = true;
						bepinexConfigButton.Visible = true;
					}
					if (steamVersion == true)
                    {
						steamLabel.Text = "Steam Version";
						steamLabel.BackColor = Color.LightBlue;
					}
					else
                    {
						steamLabel.Text = "Cracked Version";
						steamLabel.BackColor = Color.LightSeaGreen;
					}
					return;
				}
				throw new Exception("Couldn't find Mon Bazou Install Location! \n(installLoc string empty)");
			}
			catch (Exception ex)
			{
				Error(new Exception("InstallLocation was Empty. Please make sure to select the right folder!"), "INSTALLOCFAIL", important: true, needsAttention: false);
			}
		}

		private bool CheckForUpdates()
		{
			LocSetup();
			for (int i = 0; i < mod.Count; i++)
			{
				if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\MonBazouModManager\\" + mod[i].name.ToString() + ".txt"))
				{
					string text = File.ReadAllText(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\MonBazouModManager\\" + mod[i].name.ToString() + ".txt");
					if (text != mod[i].version.ToString())
					{
						MessageBox.Show("Update available for " + mod[i].name.ToString(), "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						UpdateMod(i, forced: false);
						return true;
					}
				}
			}
			return true;
		}

		private void UpdateModList()
		{
			if (Process.GetProcessesByName("Mon Bazou").Any())
			{
				MessageBox.Show("You may not use the Mod Manager while the game is running!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Application.Exit();
				Application.ExitThread();
				return;
			}
			using (WebClient webClient = new WebClient())
			{
				ServicePointManager.Expect100Continue = true;
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
				listView1.Items.Clear();
				try
				{
					string value = webClient.DownloadString(modsUrl);
					mod = JsonConvert.DeserializeObject(value);
				}
				catch (Exception ex)
				{
					Error(ex, "BACKUP-MOD-DB/FAIL", important: true, needsAttention: true);
				}
			}
			for (int i = 0; i < mod.Count; i++)
			{
				listView1.Items.Add(mod[i].name.ToString());
				if (mod[i].disabled.ToString() == "true")
				{
					listView1.Items[i].BackColor = Color.Red;
				}
				if (mod[i].disabled.ToString() == "false")
				{
					listView1.Items[i].BackColor = Color.Yellow;
				}
				if ((mod[i].dllname.ToString() != "") && (File.Exists(InstallLoc + "\\BepInEx\\plugins\\" + mod[i].dllname.ToString()) ? true : false))
				{
					if ((!File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\MonBazouModManager\\" + mod[i].name.ToString() + ".txt")))
					{
						listView1.Items.Clear();
						UpdateMod(i, forced: false);
					}
					listView1.Items[i].BackColor = Color.GreenYellow;
				}
			}
			nameTextBox.Text = "";
			authorTextBox.Text = "";
			descTextBox.Text = "";
			versionTextBox.Text = "";
			gameVersionTextBox.Text = "";
			releaseDateTextBox.Text = "";
			installButton.Enabled = false;
			deinstallButton.Enabled = false;
			reasonLabel.Visible = false;
		}

		private void UpdateMod(int modId, bool forced)
		{
			if (Process.GetProcessesByName("Mon Bazou").Any())
			{
				MessageBox.Show("You may not use the Mod Manager while the game is running!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Application.Exit();
				Application.ExitThread();
				return;
			}
			try
			{
				listView1.Items.Clear();
				using (new WebClient())
				{
					ServicePointManager.Expect100Continue = true;
					ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
					Directory.CreateDirectory(InstallLoc + "\\BepInEx\\plugins");
					Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\MonBazouModManager\\");
					File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\MonBazouModManager\\" + mod[modId].name.ToString() + ".txt", mod[modId].version.ToString());
					if (mod[modId].isZip.ToString() == "false")
					{
						File.Delete(InstallLoc + "\\BepInEx\\plugins\\" + mod[modId].dllname.ToString());
						if (DownloadFile(mod[modId].downloadurl.ToString(), InstallLoc + "\\BepInEx\\plugins\\" + mod[modId].dllname.ToString(), "Anything"))
						{
							if (!forced)
							{
								MessageBox.Show("Update for " + mod[modId].name.ToString() + " is done!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
						}
						else
						{
							Error(new Exception("Error while downloading MOD File"), "MOD-DOWNLOAD/UPDATE-FAIL", important: false, needsAttention: true);
						}
					}
					if (mod[modId].isZip.ToString() == "true")
					{
						File.Delete(InstallLoc + "\\BepInEx\\plugins\\" + mod[modId].dllname.ToString());
						if (DownloadFile(mod[modId].downloadurl.ToString(), InstallLoc + "\\BepInEx\\plugins\\" + mod[modId].zipname.ToString(), "Anything"))
						{
							ZipFile.ExtractToDirectory(InstallLoc + "\\BepInEx\\plugins\\" + mod[modId].zipname, InstallLoc + "\\BepInEx\\plugins\\");
							File.Delete(InstallLoc + "\\BepInEx\\plugins\\" + mod[modId].zipname);
							if (!forced)
							{
								MessageBox.Show("Update for " + mod[modId].name.ToString() + " is done!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
						}
						else
						{
							Error(new Exception("Error while downloading ZIP File"), "ZIP-DOWNLOAD/UPDATE-FAIL", important: false, needsAttention: true);
						}
					}
				}
				listView1.Items.Clear();
				UpdateModList();
			}
			catch (Exception ex)
			{
				Error(ex, "MOD-UPDATE-FAIL", important: false, needsAttention: true);
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			versionlabel.Text = "Version: v" + version;
			if (Process.GetProcessesByName("Mon Bazou").Any())
			{
				MessageBox.Show("You may not use the Mod Manager while the game is running!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Application.Exit();
				Application.ExitThread();
				return;
			}
			AutoUpdater.InstalledVersion = new Version(version);
			AutoUpdater.UpdateMode = Mode.Forced;
			AutoUpdater.Mandatory = true;
			AutoUpdater.Start(autoUpdate);
			LocSetup();
			SetupChangelog();
			UpdateModList();
		}

		private void listView1_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (listView1.SelectedIndices.Count <= 0)
			{
				return;
			}
			installButton.Enabled = true;
			reasonLabel.Visible = false;
			disabledLabel.Visible = false;
			nameTextBox.Text = mod[listView1.SelectedIndices[0]].name.ToString();
			authorTextBox.Text = mod[listView1.SelectedIndices[0]].author.ToString();
			descTextBox.Text = mod[listView1.SelectedIndices[0]].description.ToString();
			releaseDateTextBox.Text = mod[listView1.SelectedIndices[0]].releasedate.ToString();
			versionTextBox.Text = mod[listView1.SelectedIndices[0]].version.ToString();
			gameVersionTextBox.Text = mod[listView1.SelectedIndices[0]].gameversion.ToString();
			if (mod[listView1.SelectedIndices[0]].disabled.ToString() == "true")
			{
				if (mod[listView1.SelectedIndices[0]].reason.ToString() != "")
				{
					reasonLabel.Text = "Reason: " + mod[listView1.SelectedIndices[0]].reason.ToString();
				}
				else
				{
					reasonLabel.Text = "Reason: Unspecified";
				}
				reasonLabel.Visible = true;
				disabledLabel.Visible = true;
				installButton.Enabled = false;
				reasonLabel.Visible = true;
			}
			if (File.Exists(InstallLoc + "\\BepInEx\\plugins\\" + mod[listView1.SelectedIndices[0]].dllname.ToString()))
			{
				listView1.Items[listView1.SelectedIndices[0]].BackColor = Color.GreenYellow;
				installButton.Enabled = false;
				deinstallButton.Enabled = true;
			}
		}

		private void installButton_Click(object sender, EventArgs e)
		{
			if (Process.GetProcessesByName("Mon Bazou").Any())
			{
				MessageBox.Show("You may not use the Mod Manager while the game is running!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Application.Exit();
				Application.ExitThread();
			}
			else
			{
				if (string.IsNullOrEmpty(InstallLoc) || string.IsNullOrEmpty(nameTextBox.Text))
				{
					return;
				}
				try
				{
					if (Directory.Exists(InstallLoc + "\\BepInEx\\"))
					{
						using (new WebClient())
						{
							ServicePointManager.Expect100Continue = true;
							ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
							Directory.CreateDirectory(InstallLoc + "\\BepInEx\\plugins");
							Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\MonBazouModManager\\");
							File.WriteAllText(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\MonBazouModManager\\" + mod[listView1.SelectedIndices[0]].name.ToString() + ".txt", mod[listView1.SelectedIndices[0]].version.ToString());
							if (mod[listView1.SelectedIndices[0]].isZip.ToString() == "false")
							{
								if (DownloadFile(mod[listView1.SelectedIndices[0]].downloadurl.ToString(), InstallLoc + "\\BepInEx\\plugins\\" + mod[listView1.SelectedIndices[0]].dllname.ToString(), "Anything"))
								{
									MessageBox.Show("You can start the game now!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								else
								{
									Error(new Exception("Error while installing non-zip mod"), "INSTALLFAIL-NONZIP", important: false, needsAttention: true);
								}
							}
							if (mod[listView1.SelectedIndices[0]].isZip.ToString() == "true")
							{
								if (DownloadFile(mod[listView1.SelectedIndices[0]].downloadurl.ToString(), InstallLoc + "\\BepInEx\\plugins\\" + mod[listView1.SelectedIndices[0]].zipname.ToString(), "Anything"))
								{
									ZipFile.ExtractToDirectory(InstallLoc + "\\BepInEx\\plugins\\" + mod[listView1.SelectedIndices[0]].zipname, InstallLoc + "\\BepInEx\\plugins\\");
									File.Delete(InstallLoc + "\\BepInEx\\plugins\\" + mod[listView1.SelectedIndices[0]].zipname);
									MessageBox.Show("You can start the game now!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								else
								{
									Error(new Exception("Error while installing zip mod"), "INSTALLFAIL-ZIP", important: false, needsAttention: true);
								}
							}
							UpdateModList();
							LocSetup();
						}
						return;
					}
					MessageBox.Show("BepInEx isn't installed \nInstalling it now...", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					try
					{
						if (Directory.Exists(InstallLoc + "\\BepInEx"))
						{
							Directory.Delete(InstallLoc + "\\BepInEx");
						}
						if (File.Exists(InstallLoc + "\\winhttp.dll"))
						{
							File.Delete(InstallLoc + "\\winhttp.dll");
						}
						if (File.Exists(InstallLoc + "\\changelog.txt"))
						{
							File.Delete(InstallLoc + "\\changelog.txt");
						}
						if (File.Exists(InstallLoc + "\\doorstop_config.ini"))
						{
							File.Delete(InstallLoc + "\\doorstop_config.ini");
						}
						if (!DownloadFile(bepinexUrl, InstallLoc + "\\BepInEx.zip", "Anything"))
						{
							throw new Exception("Error while downloading BepInEx and Extracting.");
						}
						ZipFile.ExtractToDirectory(InstallLoc + "\\BepInEx.zip", InstallLoc);
						File.Delete(InstallLoc + "\\BepInEx.zip");
					}
					catch (Exception ex)
					{
						Error(ex, "WHILE-BEPINEX/INSTALL-FAIL", important: true, needsAttention: true);
					}
					try
					{
						Directory.CreateDirectory(InstallLoc + "\\BepInEx\\plugins");
						if (!(DownloadFile(mod[listView1.SelectedIndices[0]].downloadurl.ToString(), InstallLoc + "\\BepInEx\\plugins\\" + mod[listView1.SelectedIndices[0]].dllname.ToString(), "Anything") ? true : false))
						{
							throw new Exception("Error while downloading BepInEx and Extracting.");
						}
						MessageBox.Show("BepInEx and Mod installed! \nYou can start the game now!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					catch (Exception ex2)
					{
						Error(ex2, "AFTER-BEPINEX/MODINSTALL-FAIL", important: false, needsAttention: true);
					}
					listView1.Items.Clear();
					UpdateModList();
					LocSetup();
				}
				catch (Exception ex3)
				{
					Error(ex3, "MOD-INSTALL-FAIL", important: false, needsAttention: true);
				}
			}
		}

		private void deinstallButton_Click(object sender, EventArgs e)
		{
			if (Process.GetProcessesByName("Mon Bazou").Any())
			{
				MessageBox.Show("You may not use the Mod Manager while the game is running!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				Application.Exit();
				Application.ExitThread();
				return;
			}
			listView1.Items[listView1.SelectedIndices[0]].BackColor = Color.Yellow;
			try
			{
				File.Delete(InstallLoc + "\\BepInEx\\plugins\\" + mod[listView1.SelectedIndices[0]].dllname.ToString());
				File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\MonBazouModManager\\" + mod[listView1.SelectedIndices[0]].name.ToString() + ".txt");
				if (mod[listView1.SelectedIndices[0]].isZip.ToString() == "true")
				{
					Directory.Delete(InstallLoc + "\\BepInEx\\plugins\\" + mod[listView1.SelectedIndices[0]].name.ToString());
				}
				MessageBox.Show("You can start the game now!", "Mon Bazou - Mod Manager Crack", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			catch (Exception ex)
			{
				Error(ex, "MOD-UNINSTALL-FAIL", important: false, needsAttention: true);
			}
			UpdateModList();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			AutoUpdater.Start(autoUpdate);
		}

		private void forceUpdateButton_Click(object sender, EventArgs e)
		{
			LocSetup();
			UpdateModList();
			for (int i = 0; i < mod.Count; i++)
			{
				if (File.Exists(InstallLoc + "\\BepInEx\\plugins\\" + mod[i].dllname.ToString()))
				{
					UpdateMod(i, forced: true);
				}
			}
			MessageBox.Show("Force Update Done ", "Mod Manager Crack - Mon Bazou", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		private void refreshButton_Click(object sender, EventArgs e)
		{
			listView1.Items.Clear();
			LocSetup();
			UpdateModList();
			CheckForUpdates();
		}

		private void bepinexButton_Click(object sender, EventArgs e)
		{
			Process.Start(InstallLoc + "\\BepInEx\\");
		}

		private void bepinexConfigButton_Click(object sender, EventArgs e)
		{
			Process.Start(InstallLoc + "\\BepInEx\\config");
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Process.Start("https://github.com/BeterSussin/modloader");
		}

		private void changelogLabel_Click(object sender, EventArgs e)
		{
			SoundPlayer soundPlayer = new SoundPlayer(Resources.sui);
			soundPlayer.Play();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			tabControl1 = new System.Windows.Forms.TabControl();
			mainMenu = new System.Windows.Forms.TabPage();
			versionlabel = new System.Windows.Forms.Label();
			label7 = new System.Windows.Forms.Label();
			button2 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			bepinexConfigButton = new System.Windows.Forms.Button();
			bepinexButton = new System.Windows.Forms.Button();
			bepinexLabel = new System.Windows.Forms.Label();
			steamLabel = new System.Windows.Forms.Label();
			installLocLabel = new System.Windows.Forms.Label();
			textBox1 = new System.Windows.Forms.TextBox();
			changelogLabel = new System.Windows.Forms.Label();
			modsMenu = new System.Windows.Forms.TabPage();
			label10 = new System.Windows.Forms.Label();
			label9 = new System.Windows.Forms.Label();
			label8 = new System.Windows.Forms.Label();
			refreshButton = new System.Windows.Forms.Button();
			forceUpdateButton = new System.Windows.Forms.Button();
			listView1 = new System.Windows.Forms.ListView();
			groupBox1 = new System.Windows.Forms.GroupBox();
			reasonLabel = new System.Windows.Forms.Label();
			disabledLabel = new System.Windows.Forms.Label();
			deinstallButton = new System.Windows.Forms.Button();
			installButton = new System.Windows.Forms.Button();
			descTextBox = new System.Windows.Forms.TextBox();
			label6 = new System.Windows.Forms.Label();
			authorTextBox = new System.Windows.Forms.TextBox();
			label5 = new System.Windows.Forms.Label();
			releaseDateTextBox = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			gameVersionTextBox = new System.Windows.Forms.TextBox();
			label3 = new System.Windows.Forms.Label();
			versionTextBox = new System.Windows.Forms.TextBox();
			label2 = new System.Windows.Forms.Label();
			nameTextBox = new System.Windows.Forms.TextBox();

			label1 = new System.Windows.Forms.Label();
			tabControl1.SuspendLayout();
			mainMenu.SuspendLayout();
			modsMenu.SuspendLayout();
			groupBox1.SuspendLayout();

			SuspendLayout();
			tabControl1.Controls.Add(mainMenu);
			tabControl1.Controls.Add(modsMenu);

			tabControl1.Location = new System.Drawing.Point(12, 12);
			tabControl1.Name = "tabControl1";
			tabControl1.SelectedIndex = 0;
			tabControl1.Size = new System.Drawing.Size(901, 482);
			tabControl1.TabIndex = 0;
			mainMenu.Controls.Add(versionlabel);
			mainMenu.Controls.Add(label7);
			mainMenu.Controls.Add(button2);
			mainMenu.Controls.Add(button1);
			mainMenu.Controls.Add(bepinexConfigButton);
			mainMenu.Controls.Add(bepinexButton);
			mainMenu.Controls.Add(bepinexLabel);
			mainMenu.Controls.Add(steamLabel);
			mainMenu.Controls.Add(installLocLabel);
			mainMenu.Controls.Add(textBox1);
			mainMenu.Controls.Add(changelogLabel);
			mainMenu.Location = new System.Drawing.Point(4, 22);
			mainMenu.Name = "mainMenu";
			mainMenu.Padding = new System.Windows.Forms.Padding(3);
			mainMenu.Size = new System.Drawing.Size(893, 456);
			mainMenu.TabIndex = 0;
			mainMenu.Text = "Main Menu";
			mainMenu.UseVisualStyleBackColor = true;
			versionlabel.AutoSize = true;
			versionlabel.Location = new System.Drawing.Point(195, 379);
			versionlabel.Name = "versionlabel";
			versionlabel.Size = new System.Drawing.Size(45, 13);
			versionlabel.TabIndex = 10;
			versionlabel.Text = "Version:";
			label7.AutoSize = true;
			label7.Location = new System.Drawing.Point(54, 395);
			label7.Name = "label7";
			label7.Size = new System.Drawing.Size(300, 13);
			label7.TabIndex = 9;
			label7.Text = "Mon Bazou Mod Manager Cracked --- Developed by BeterSussin";
			button2.Location = new System.Drawing.Point(149, 414);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(338, 33);
			button2.TabIndex = 8;
			button2.Text = "Open Github from BeterSussin";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button1.Location = new System.Drawing.Point(10, 414);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(132, 33);
			button1.TabIndex = 7;
			button1.Text = "Check for Updates";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			bepinexConfigButton.Location = new System.Drawing.Point(186, 111);
			bepinexConfigButton.Name = "bepinexConfigButton";
			bepinexConfigButton.Size = new System.Drawing.Size(217, 27);
			bepinexConfigButton.TabIndex = 6;
			bepinexConfigButton.Text = "Open BepInEx Config Folder";
			bepinexConfigButton.UseVisualStyleBackColor = true;
			bepinexConfigButton.Click += new System.EventHandler(bepinexConfigButton_Click);
			bepinexButton.Location = new System.Drawing.Point(7, 111);
			bepinexButton.Name = "bepinexButton";
			bepinexButton.Size = new System.Drawing.Size(173, 27);
			bepinexButton.TabIndex = 5;
			bepinexButton.Text = "Open BepInEx Folder";
			bepinexButton.UseVisualStyleBackColor = true;
			bepinexButton.Click += new System.EventHandler(bepinexButton_Click);
			steamLabel.AutoSize = true;
			steamLabel.Location = new System.Drawing.Point(7, 85);
			steamLabel.Name = "steamLabel";
			steamLabel.Size = new System.Drawing.Size(35, 13);
			steamLabel.TabIndex = 4;
			steamLabel.Text = "label2";
			bepinexLabel.AutoSize = true;
			bepinexLabel.Location = new System.Drawing.Point(7, 60);
			bepinexLabel.Name = "bepinexLabel";
			bepinexLabel.Size = new System.Drawing.Size(35, 13);
			bepinexLabel.TabIndex = 3;
			bepinexLabel.Text = "label2";
			installLocLabel.AutoSize = true;
			installLocLabel.Location = new System.Drawing.Point(7, 15);
			installLocLabel.Name = "installLocLabel";
			installLocLabel.Size = new System.Drawing.Size(35, 13);
			installLocLabel.TabIndex = 2;
			installLocLabel.Text = "label2";
			textBox1.Location = new System.Drawing.Point(493, 35);
			textBox1.Multiline = true;
			textBox1.Name = "textBox1";
			textBox1.ReadOnly = true;
			textBox1.Size = new System.Drawing.Size(394, 412);
			textBox1.TabIndex = 1;
			changelogLabel.AutoSize = true;
			changelogLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			changelogLabel.Location = new System.Drawing.Point(641, 11);
			changelogLabel.Name = "changelogLabel";
			changelogLabel.Size = new System.Drawing.Size(95, 20);
			changelogLabel.TabIndex = 0;
			changelogLabel.Text = "Changelog";
			changelogLabel.Click += new System.EventHandler(changelogLabel_Click);
			modsMenu.Controls.Add(label10);
			modsMenu.Controls.Add(label9);
			modsMenu.Controls.Add(label8);
			modsMenu.Controls.Add(refreshButton);
			modsMenu.Controls.Add(forceUpdateButton);
			modsMenu.Controls.Add(listView1);
			modsMenu.Controls.Add(groupBox1);
			modsMenu.Location = new System.Drawing.Point(4, 22);
			modsMenu.Name = "modsMenu";
			modsMenu.Padding = new System.Windows.Forms.Padding(3);
			modsMenu.Size = new System.Drawing.Size(893, 456);
			modsMenu.TabIndex = 1;
			modsMenu.Text = "Mods";
			modsMenu.UseVisualStyleBackColor = true;
			label10.AutoSize = true;
			label10.BackColor = System.Drawing.Color.Lime;
			label10.Location = new System.Drawing.Point(254, 381);
			label10.Name = "label10";
			label10.Size = new System.Drawing.Size(46, 13);
			label10.TabIndex = 6;
			label10.Text = "Installed";
			label9.AutoSize = true;
			label9.BackColor = System.Drawing.Color.Yellow;
			label9.Location = new System.Drawing.Point(149, 381);
			label9.Name = "label9";
			label9.Size = new System.Drawing.Size(80, 13);
			label9.TabIndex = 5;
			label9.Text = "Ready to Install";
			label8.AutoSize = true;
			label8.BackColor = System.Drawing.Color.Red;
			label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			label8.Location = new System.Drawing.Point(81, 381);
			label8.Name = "label8";
			label8.Size = new System.Drawing.Size(48, 13);
			label8.TabIndex = 4;
			label8.Text = "Disabled";
			refreshButton.Location = new System.Drawing.Point(229, 408);
			refreshButton.Name = "refreshButton";
			refreshButton.Size = new System.Drawing.Size(176, 39);
			refreshButton.TabIndex = 3;
			refreshButton.Text = "Refresh";
			refreshButton.UseVisualStyleBackColor = true;
			refreshButton.Click += new System.EventHandler(refreshButton_Click);
			forceUpdateButton.Location = new System.Drawing.Point(7, 408);
			forceUpdateButton.Name = "forceUpdateButton";
			forceUpdateButton.Size = new System.Drawing.Size(170, 39);
			forceUpdateButton.TabIndex = 2;
			forceUpdateButton.Text = "Force Update";
			forceUpdateButton.UseVisualStyleBackColor = true;
			forceUpdateButton.Click += new System.EventHandler(forceUpdateButton_Click);
			listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			listView1.FullRowSelect = true;
			listView1.HideSelection = false;
			listView1.Location = new System.Drawing.Point(7, 7);
			listView1.MultiSelect = false;
			listView1.Name = "listView1";
			listView1.ShowGroups = false;
			listView1.Size = new System.Drawing.Size(398, 363);
			listView1.TabIndex = 1;
			listView1.UseCompatibleStateImageBehavior = false;
			listView1.View = System.Windows.Forms.View.List;
			listView1.SelectedIndexChanged += new System.EventHandler(listView1_SelectedIndexChanged);
			groupBox1.Controls.Add(reasonLabel);
			groupBox1.Controls.Add(disabledLabel);
			groupBox1.Controls.Add(deinstallButton);
			groupBox1.Controls.Add(installButton);
			groupBox1.Controls.Add(descTextBox);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(authorTextBox);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(releaseDateTextBox);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(gameVersionTextBox);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(versionTextBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(nameTextBox);
			groupBox1.Location = new System.Drawing.Point(423, 7);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(464, 440);
			groupBox1.TabIndex = 0;
			groupBox1.TabStop = false;
			groupBox1.Text = "Info";
			reasonLabel.AutoSize = true;
			reasonLabel.Location = new System.Drawing.Point(10, 347);
			reasonLabel.Name = "reasonLabel";
			reasonLabel.Size = new System.Drawing.Size(47, 13);
			reasonLabel.TabIndex = 14;
			reasonLabel.Text = "Reason:";
			disabledLabel.AutoSize = true;
			disabledLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			disabledLabel.ForeColor = System.Drawing.Color.Red;
			disabledLabel.Location = new System.Drawing.Point(26, 297);
			disabledLabel.Name = "disabledLabel";
			disabledLabel.Size = new System.Drawing.Size(411, 31);
			disabledLabel.TabIndex = 13;
			disabledLabel.Text = "This Mod is currently disabled!";
			disabledLabel.Visible = false;
			deinstallButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			deinstallButton.Location = new System.Drawing.Point(237, 387);
			deinstallButton.Name = "deinstallButton";
			deinstallButton.Size = new System.Drawing.Size(221, 47);
			deinstallButton.TabIndex = 12;
			deinstallButton.Text = "Deinstall";
			deinstallButton.UseVisualStyleBackColor = true;
			deinstallButton.Click += new System.EventHandler(deinstallButton_Click);
			installButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			installButton.Location = new System.Drawing.Point(10, 387);
			installButton.Name = "installButton";
			installButton.Size = new System.Drawing.Size(221, 47);
			installButton.TabIndex = 11;
			installButton.Text = "Install";
			installButton.UseVisualStyleBackColor = true;
			installButton.Click += new System.EventHandler(installButton_Click);
			descTextBox.Enabled = false;
			descTextBox.Location = new System.Drawing.Point(6, 139);
			descTextBox.Multiline = true;
			descTextBox.Name = "descTextBox";
			descTextBox.ReadOnly = true;
			descTextBox.Size = new System.Drawing.Size(452, 155);
			descTextBox.TabIndex = 10;
			label6.AutoSize = true;
			label6.Location = new System.Drawing.Point(234, 70);
			label6.Name = "label6";
			label6.Size = new System.Drawing.Size(41, 13);
			label6.TabIndex = 9;
			label6.Text = "Author:";
			authorTextBox.Enabled = false;
			authorTextBox.Location = new System.Drawing.Point(237, 88);
			authorTextBox.Name = "authorTextBox";
			authorTextBox.ReadOnly = true;
			authorTextBox.Size = new System.Drawing.Size(221, 20);
			authorTextBox.TabIndex = 8;
			label5.AutoSize = true;
			label5.Location = new System.Drawing.Point(7, 70);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(75, 13);
			label5.TabIndex = 7;
			label5.Text = "Release Date:";
			releaseDateTextBox.Enabled = false;
			releaseDateTextBox.Location = new System.Drawing.Point(6, 89);
			releaseDateTextBox.Name = "releaseDateTextBox";
			releaseDateTextBox.ReadOnly = true;
			releaseDateTextBox.Size = new System.Drawing.Size(225, 20);
			releaseDateTextBox.TabIndex = 6;
			label4.AutoSize = true;
			label4.Location = new System.Drawing.Point(341, 22);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(76, 13);
			label4.TabIndex = 5;
			label4.Text = "Game Version:";
			gameVersionTextBox.Enabled = false;
			gameVersionTextBox.Location = new System.Drawing.Point(344, 41);
			gameVersionTextBox.Name = "gameVersionTextBox";
			gameVersionTextBox.ReadOnly = true;
			gameVersionTextBox.Size = new System.Drawing.Size(114, 20);
			gameVersionTextBox.TabIndex = 4;
			label3.AutoSize = true;
			label3.Location = new System.Drawing.Point(243, 22);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(45, 13);
			label3.TabIndex = 3;
			label3.Text = "Version:";
			versionTextBox.Enabled = false;
			versionTextBox.Location = new System.Drawing.Point(237, 41);
			versionTextBox.Name = "versionTextBox";
			versionTextBox.ReadOnly = true;
			versionTextBox.Size = new System.Drawing.Size(100, 20);
			versionTextBox.TabIndex = 2;
			label2.AutoSize = true;
			label2.Location = new System.Drawing.Point(7, 22);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(38, 13);
			label2.TabIndex = 1;
			label2.Text = "Name:";
			nameTextBox.Enabled = false;
			nameTextBox.Location = new System.Drawing.Point(6, 41);
			nameTextBox.Name = "nameTextBox";
			nameTextBox.ReadOnly = true;
			nameTextBox.Size = new System.Drawing.Size(225, 20);
			nameTextBox.TabIndex = 0;

			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			base.ClientSize = new System.Drawing.Size(925, 506);
			base.Controls.Add(tabControl1);
			base.MaximizeBox = false;
			base.Name = "Form1";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "Mon Bazou - Mod Manager Crack";
			base.Load += new System.EventHandler(Form1_Load);
			tabControl1.ResumeLayout(false);
			mainMenu.ResumeLayout(false);
			mainMenu.PerformLayout();
			modsMenu.ResumeLayout(false);
			modsMenu.PerformLayout();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();

			ResumeLayout(false);
		}
	}
}
